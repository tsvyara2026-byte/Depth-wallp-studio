package com.depthwallpaper.studio

import android.app.Activity
import android.content.ContentValues
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var preview: ImageView
    private lateinit var clock: TextView
    private lateinit var status: TextView
    private var original: Bitmap? = null
    private var cutout: Bitmap? = null
    private var background: Bitmap? = null
    private var clockColor = Color.WHITE
    private var clockSize = 54f
    private var depthReady = false
    private var blurMode = false

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadPhoto(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(15, 18, 32))
        }
        val heading = TextView(this).apply {
            text = "DEPTH WALLPAPER STUDIO"
            textSize = 21f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setPadding(0, 8, 0, 14)
        }
        page.addView(heading)

        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(35, 41, 62))
        }
        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(35, 41, 62))
        }
        frame.addView(preview, FrameLayout.LayoutParams(-1, -1))
        clock = TextView(this).apply {
            text = "10:08\n${SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date())}"
            textSize = 30f; setTextColor(clockColor); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setShadowLayer(8f, 1f, 2f, Color.BLACK)
        }
        val clockLp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        clockLp.topMargin = 42
        frame.addView(clock, clockLp)
        page.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        status = TextView(this).apply {
            text = "તમારો ફોટો પસંદ કરો અને Depth Effect બનાવો"
            setTextColor(Color.LTGRAY); textSize = 13f; gravity = Gravity.CENTER
            setPadding(0, 10, 0, 8)
        }
        page.addView(status)

        val choose = button("ફોટો પસંદ કરો") { picker.launch("image/*") }
        page.addView(choose)
        page.addView(button("✨ Advanced Depth Effect બનાવો") { createDepth() })
        page.addView(button("Clock Font બદલો") { cycleFont() })
        page.addView(button("Clock Colour બદલો") { cycleColor() })
        page.addView(button("Clock Size +") { clockSize = (clockSize + 5f).coerceAtMost(90f); clock.textSize = clockSize })
        page.addView(button("Clock Position બદલો") { moveClock() })
        page.addView(button("Background Blur On / Off") { blurMode = !blurMode; renderPreview() })
        page.addView(button("Wallpaper Gallery માં સેવ કરો") { saveWallpaper() })
        setContentView(page)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false
        setOnClickListener { action() }
    }

    private fun loadPhoto(uri: Uri) {
        try {
            val bmp = if (android.os.Build.VERSION.SDK_INT >= 28) {
                val source = ImageDecoder.createSource(contentResolver, uri)
                ImageDecoder.decodeBitmap(source) { decoder, _, _ -> decoder.isMutableRequired = true }
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(contentResolver, uri)
            }
            original = bmp.copy(Bitmap.Config.ARGB_8888, true)
            background = original
            cutout = null
            depthReady = false
            status.text = "ફોટો લોડ થયો. હવે Advanced Depth બનાવો."
            renderPreview()
        } catch (e: Exception) {
            status.text = "ફોટો ખોલી શકાયો નથી: ${e.localizedMessage}"
        }
    }

    private fun createDepth() {
        val bmp = original ?: run { status.text = "પહેલા ફોટો પસંદ કરો."; return }
        status.text = "AI subject ઓળખી રહ્યું છે…"
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .enableRawSizeMask()
            .build()
        val segmenter = Segmentation.getClient(options)
        segmenter.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { mask ->
                try {
                    val buffer = mask.buffer
                    buffer.rewind()
                    val mw = mask.width()
                    val mh = mask.height()
                    val out = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                    val pixels = IntArray(bmp.width * bmp.height)
                    val row = FloatArray(mw)
                    for (y in 0 until bmp.height) {
                        val my = min(mh - 1, y * mh / bmp.height)
                        for (x in 0 until bmp.width) {
                            val mx = min(mw - 1, x * mw / bmp.width)
                            val idx = my * mw + mx
                            val confidence = buffer.getFloat(idx * 4).coerceIn(0f, 1f)
                            row[mx] = confidence
                            val src = bmp.getPixel(x, y)
                            val alpha = (confidence * 255).toInt()
                            pixels[y * bmp.width + x] = (alpha shl 24) or (src and 0x00FFFFFF)
                        }
                    }
                    out.setPixels(pixels, 0, bmp.width, 0, 0, bmp.width, bmp.height)
                    cutout = out
                    depthReady = true
                    status.text = "Depth તૈયાર! ઘડિયાળને Subject ની પાછળ ગોઠવવામાં આવી છે."
                    renderPreview()
                } catch (e: Exception) {
                    status.text = "Depth બનાવવામાં મુશ્કેલી: ${e.localizedMessage}"
                } finally {
                    segmenter.close()
                }
            }
            .addOnFailureListener {
                segmenter.close()
                status.text = "AI Depth નિષ્ફળ થયું. વધુ સ્પષ્ટ portrait ફોટો અજમાવો."
            }
    }

    private fun renderPreview() {
        val base = background ?: run { preview.setImageDrawable(null); return }
        val w = 720
        val h = (w.toFloat() * base.height / base.width).toInt().coerceAtLeast(900)
        val scaled = Bitmap.createScaledBitmap(base, w, h, true)
        val canvasBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(canvasBmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (blurMode) paint.maskFilter = BlurMaskFilter(2f, BlurMaskFilter.Blur.NORMAL)
        c.drawBitmap(scaled, null, Rect(0, 0, w, h), paint)
        // Clock is rendered between background and extracted subject for the depth illusion.
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = clockColor; textAlign = Paint.Align.CENTER; textSize = clockSize * 1.7f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setShadowLayer(8f, 1f, 2f, Color.BLACK)
        }
        val now = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        c.drawText(now, w / 2f, 170f, p)
        p.textSize = 30f
        c.drawText(SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date()), w / 2f, 212f, p)
        cutout?.let { fg ->
            val scaledFg = Bitmap.createScaledBitmap(fg, w, h, true)
            c.drawBitmap(scaledFg, null, Rect(0, 0, w, h), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        }
        preview.setImageBitmap(canvasBmp)
    }

    private fun cycleFont() {
        val fonts = arrayOf("sans-serif", "sans-serif-light", "sans-serif-condensed", "serif", "monospace")
        val current = (clock.tag as? Int ?: 0)
        val next = (current + 1) % fonts.size
        clock.tag = next
        clock.typeface = Typeface.create(fonts[next], Typeface.NORMAL)
        renderPreview()
    }

    private fun cycleColor() {
        val colors = intArrayOf(Color.WHITE, Color.CYAN, Color.YELLOW, Color.MAGENTA, Color.rgb(255, 170, 120))
        val i = (clock.tag as? Int ?: 0) % colors.size
        clockColor = colors[i]
        clock.setTextColor(clockColor)
        clock.tag = i + 1
        renderPreview()
    }

    private fun moveClock() {
        val lp = clock.layoutParams as FrameLayout.LayoutParams
        lp.topMargin = if (lp.topMargin < 220) lp.topMargin + 70 else 42
        clock.layoutParams = lp
        renderPreview()
    }

    private fun saveWallpaper() {
        val bmp = (preview.drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap
            ?: run { status.text = "પહેલા ફોટો પસંદ કરો."; return }
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "DepthWallpaper_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DepthWallpaperStudio")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            status.text = "Wallpaper Gallery માં સેવ થયું."
        } else status.text = "સેવ કરી શકાયું નથી."
    }
}
